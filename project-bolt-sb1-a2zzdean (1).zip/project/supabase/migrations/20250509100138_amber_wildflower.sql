/*
  # Add Motivation Tracking Tables

  1. New Tables
    - motivation_actions (for storing daily motivation actions)
    - motivation_logs (for tracking completion and ratings)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create motivation_actions table
CREATE TABLE IF NOT EXISTS motivation_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  time_of_day time NOT NULL,
  duration_minutes integer NOT NULL CHECK (duration_minutes > 0 AND duration_minutes <= 15),
  importance text NOT NULL,
  potential_obstacle text,
  solution text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create motivation_logs table
CREATE TABLE IF NOT EXISTS motivation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  motivation_rating integer NOT NULL CHECK (motivation_rating BETWEEN 1 AND 10),
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE motivation_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE motivation_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for motivation_actions
CREATE POLICY "Users can manage their motivation actions"
  ON motivation_actions
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policies for motivation_logs
CREATE POLICY "Users can manage their motivation logs"
  ON motivation_logs
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);