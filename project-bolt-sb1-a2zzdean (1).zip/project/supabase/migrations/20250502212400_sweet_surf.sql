/*
  # Initial Schema Setup

  1. New Tables
    - users (linked to auth.users)
    - journal_entries (for mood tracking)
    - emotions (predefined emotion tags)
    - activities (predefined activity tags)
    - entry_emotions (junction table)
    - entry_activities (junction table)
    - user_settings (user preferences)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Set up proper foreign key relationships

  3. Initial Data
    - Default emotions
    - Default activities
*/

-- Create extension if it doesn't exist
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$ BEGIN
  -- Create users table if it doesn't exist
  CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY,
    email text NOT NULL,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE
  );

  -- Create journal_entries table if it doesn't exist
  CREATE TABLE IF NOT EXISTS journal_entries (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid NOT NULL,
    mood_rating integer NOT NULL CHECK (mood_rating BETWEEN 1 AND 5),
    journal_text text,
    date timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  -- Create emotions table if it doesn't exist
  CREATE TABLE IF NOT EXISTS emotions (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name text NOT NULL UNIQUE,
    created_at timestamptz DEFAULT now()
  );

  -- Create activities table if it doesn't exist
  CREATE TABLE IF NOT EXISTS activities (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name text NOT NULL UNIQUE,
    created_at timestamptz DEFAULT now()
  );

  -- Create junction tables if they don't exist
  CREATE TABLE IF NOT EXISTS entry_emotions (
    entry_id uuid NOT NULL,
    emotion_id uuid NOT NULL,
    PRIMARY KEY (entry_id, emotion_id),
    FOREIGN KEY (entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
    FOREIGN KEY (emotion_id) REFERENCES emotions(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS entry_activities (
    entry_id uuid NOT NULL,
    activity_id uuid NOT NULL,
    PRIMARY KEY (entry_id, activity_id),
    FOREIGN KEY (entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
    FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
  );

  -- Create user_settings table if it doesn't exist
  CREATE TABLE IF NOT EXISTS user_settings (
    user_id uuid PRIMARY KEY,
    reminder_enabled boolean DEFAULT false,
    reminder_time time DEFAULT '20:00',
    show_quotes boolean DEFAULT true,
    updated_at timestamptz DEFAULT now(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
END $$;

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE emotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE entry_emotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE entry_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
DO $$ BEGIN
  -- Users table policies
  CREATE POLICY "Users can view own profile" ON users
    FOR SELECT USING (auth.uid() = id);
  
  CREATE POLICY "Users can update own profile" ON users
    FOR UPDATE USING (auth.uid() = id);

  -- Journal entries policies
  CREATE POLICY "Users can view own entries" ON journal_entries
    FOR SELECT USING (auth.uid() = user_id);
  
  CREATE POLICY "Users can insert own entries" ON journal_entries
    FOR INSERT WITH CHECK (auth.uid() = user_id);
  
  CREATE POLICY "Users can update own entries" ON journal_entries
    FOR UPDATE USING (auth.uid() = user_id);
  
  CREATE POLICY "Users can delete own entries" ON journal_entries
    FOR DELETE USING (auth.uid() = user_id);

  -- Emotions and activities policies
  CREATE POLICY "Everyone can view emotions" ON emotions
    FOR SELECT USING (true);
  
  CREATE POLICY "Everyone can view activities" ON activities
    FOR SELECT USING (true);

  -- Junction table policies
  CREATE POLICY "Users can manage their entry emotions" ON entry_emotions
    FOR ALL USING (
      EXISTS (
        SELECT 1 FROM journal_entries
        WHERE id = entry_id AND user_id = auth.uid()
      )
    );
  
  CREATE POLICY "Users can manage their entry activities" ON entry_activities
    FOR ALL USING (
      EXISTS (
        SELECT 1 FROM journal_entries
        WHERE id = entry_id AND user_id = auth.uid()
      )
    );

  -- User settings policies
  CREATE POLICY "Users can view own settings" ON user_settings
    FOR SELECT USING (auth.uid() = user_id);
  
  CREATE POLICY "Users can insert own settings" ON user_settings
    FOR INSERT WITH CHECK (auth.uid() = user_id);
  
  CREATE POLICY "Users can update own settings" ON user_settings
    FOR UPDATE USING (auth.uid() = user_id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Insert default emotions if they don't exist
INSERT INTO emotions (name) VALUES
  ('Happy'),
  ('Calm'),
  ('Anxious'),
  ('Sad'),
  ('Angry'),
  ('Energetic'),
  ('Tired'),
  ('Grateful'),
  ('Stressed'),
  ('Peaceful')
ON CONFLICT (name) DO NOTHING;

-- Insert default activities if they don't exist
INSERT INTO activities (name) VALUES
  ('Work'),
  ('Exercise'),
  ('Social interaction'),
  ('Family time'),
  ('Sleep'),
  ('Eating habits'),
  ('Meditation'),
  ('Time in nature'),
  ('Screen time'),
  ('Hobbies')
ON CONFLICT (name) DO NOTHING;

-- Create function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (id, email)
  VALUES (new.id, new.email);

  INSERT INTO public.user_settings (user_id)
  VALUES (new.id);

  RETURN new;
END;
$$;

-- Create trigger for new user creation
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();