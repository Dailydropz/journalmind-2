/*
  # Add Additional Fields to Journal Entries

  1. Changes
    - Add energy_level field
    - Add sleep_quality field
    - Add physical_symptoms array field
    - Add triggers array field

  2. Security
    - Maintain existing RLS policies
    - No changes to access control needed
*/

ALTER TABLE journal_entries
ADD COLUMN IF NOT EXISTS energy_level text,
ADD COLUMN IF NOT EXISTS sleep_quality integer CHECK (sleep_quality BETWEEN 1 AND 10),
ADD COLUMN IF NOT EXISTS physical_symptoms text[],
ADD COLUMN IF NOT EXISTS triggers text[];