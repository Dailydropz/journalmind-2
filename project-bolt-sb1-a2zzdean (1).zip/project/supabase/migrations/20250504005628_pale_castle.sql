/*
  # Add Insert Policy for Users Table

  1. Changes
    - Add new RLS policy to allow users to insert their own records
    - Policy ensures users can only create records with their own auth ID

  2. Security
    - Maintains data isolation between users
    - Only allows users to create their own records
*/

-- Add insert policy for users table
CREATE POLICY "Users can insert own record" ON users
  FOR INSERT 
  WITH CHECK (auth.uid() = id);