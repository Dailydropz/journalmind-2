import { corsHeaders } from '../_shared/cors.ts';

interface Quote {
  q: string;
  a: string;
  h: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const response = await fetch('https://zenquotes.io/api/random');
    const quotes: Quote[] = await response.json();
    
    if (!Array.isArray(quotes) || quotes.length === 0) {
      throw new Error('Invalid response from Zenquotes API');
    }

    const quote = quotes[0];
    
    return new Response(
      JSON.stringify({
        text: quote.q,
        author: quote.a
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Failed to fetch quote'
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});