import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { 
  JournalEntry, 
  MoodRating, 
  Emotion, 
  Activity, 
  AppSettings, 
  Quote,
  JournalPrompt
} from '../types';
import { 
  initialJournalEntries, 
  initialEmotions, 
  initialActivities, 
  initialSettings,
  quotes,
  journalPrompts
} from '../data/initialData';

type AppState = {
  journalEntries: JournalEntry[];
  emotions: Emotion[];
  activities: Activity[];
  settings: AppSettings;
  quotes: Quote[];
  journalPrompts: JournalPrompt[];
  currentQuote: Quote | null;
};

type AppAction =
  | { type: 'ADD_ENTRY'; payload: JournalEntry }
  | { type: 'UPDATE_ENTRY'; payload: JournalEntry }
  | { type: 'DELETE_ENTRY'; payload: string }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<AppSettings> }
  | { type: 'SET_RANDOM_QUOTE' };

const initialState: AppState = {
  journalEntries: initialJournalEntries,
  emotions: initialEmotions,
  activities: initialActivities,
  settings: initialSettings,
  quotes,
  journalPrompts,
  currentQuote: null,
};

// Load data from localStorage
const loadState = (): AppState => {
  try {
    const savedState = localStorage.getItem('moodTrackerState');
    if (savedState) {
      return JSON.parse(savedState);
    }
  } catch (error) {
    console.error('Error loading state from localStorage:', error);
  }
  return initialState;
};

// Save data to localStorage
const saveState = (state: AppState) => {
  try {
    localStorage.setItem('moodTrackerState', JSON.stringify(state));
  } catch (error) {
    console.error('Error saving state to localStorage:', error);
  }
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'ADD_ENTRY':
      return {
        ...state,
        journalEntries: [...state.journalEntries, action.payload],
      };
    case 'UPDATE_ENTRY':
      return {
        ...state,
        journalEntries: state.journalEntries.map((entry) =>
          entry.id === action.payload.id ? action.payload : entry
        ),
      };
    case 'DELETE_ENTRY':
      return {
        ...state,
        journalEntries: state.journalEntries.filter((entry) => entry.id !== action.payload),
      };
    case 'UPDATE_SETTINGS':
      return {
        ...state,
        settings: {
          ...state.settings,
          ...action.payload,
        },
      };
    case 'SET_RANDOM_QUOTE':
      const randomIndex = Math.floor(Math.random() * state.quotes.length);
      return {
        ...state,
        currentQuote: state.quotes[randomIndex],
      };
    default:
      return state;
  }
};

type AppContextType = {
  state: AppState;
  addEntry: (entry: Omit<JournalEntry, 'id' | 'createdAt'>) => void;
  updateEntry: (entry: JournalEntry) => void;
  deleteEntry: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  setRandomQuote: () => void;
  exportData: () => void;
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState, loadState);

  // Save state to localStorage when it changes
  useEffect(() => {
    saveState(state);
  }, [state]);

  // Set a random quote on initial load
  useEffect(() => {
    if (!state.currentQuote) {
      dispatch({ type: 'SET_RANDOM_QUOTE' });
    }
  }, [state.currentQuote]);

  const addEntry = (entry: Omit<JournalEntry, 'id' | 'createdAt'>) => {
    const newEntry: JournalEntry = {
      ...entry,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
    };
    dispatch({ type: 'ADD_ENTRY', payload: newEntry });
  };

  const updateEntry = (entry: JournalEntry) => {
    dispatch({ type: 'UPDATE_ENTRY', payload: entry });
  };

  const deleteEntry = (id: string) => {
    dispatch({ type: 'DELETE_ENTRY', payload: id });
  };

  const updateSettings = (settings: Partial<AppSettings>) => {
    dispatch({ type: 'UPDATE_SETTINGS', payload: settings });
  };

  const setRandomQuote = () => {
    dispatch({ type: 'SET_RANDOM_QUOTE' });
  };

  const exportData = () => {
    const dataStr = JSON.stringify(state.journalEntries, null, 2);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    
    const exportFileDefaultName = `mood-tracker-export-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <AppContext.Provider
      value={{
        state,
        addEntry,
        updateEntry,
        deleteEntry,
        updateSettings,
        setRandomQuote,
        exportData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};