export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
};

export const formatTime = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const getDateOnly = (dateString: string): string => {
  return new Date(dateString).toISOString().split('T')[0];
};

export const isToday = (dateString: string): boolean => {
  const today = new Date();
  const date = new Date(dateString);
  return (
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
  );
};

export const isYesterday = (dateString: string): boolean => {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const date = new Date(dateString);
  return (
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear()
  );
};

export const getLastNDays = (n: number): Date[] => {
  const result: Date[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    result.push(date);
  }
  return result;
};

export const getDayOfMonth = (dateString: string): number => {
  return new Date(dateString).getDate();
};

export const getMonthName = (dateString: string): string => {
  return new Date(dateString).toLocaleString('default', { month: 'long' });
};

export const getCurrentMonthDates = (): Date[] => {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  
  const dates: Date[] = [];
  for (let d = new Date(firstDayOfMonth); d <= lastDayOfMonth; d.setDate(d.getDate() + 1)) {
    dates.push(new Date(d));
  }
  
  return dates;
};

export const getRelativeDayText = (dateString: string): string => {
  if (isToday(dateString)) {
    return 'Today';
  } else if (isYesterday(dateString)) {
    return 'Yesterday';
  } else {
    return formatDate(dateString);
  }
};