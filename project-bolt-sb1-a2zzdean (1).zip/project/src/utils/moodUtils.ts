import { JournalEntry, MoodRating, MoodStats } from '../types';

export const getMoodColor = (rating: MoodRating): string => {
  switch (rating) {
    case 1: return 'bg-red-500';
    case 2: return 'bg-orange-400';
    case 3: return 'bg-yellow-300';
    case 4: return 'bg-green-300';
    case 5: return 'bg-green-500';
    default: return 'bg-gray-300';
  }
};

export const getMoodTextColor = (rating: MoodRating): string => {
  switch (rating) {
    case 1: return 'text-red-500';
    case 2: return 'text-orange-400';
    case 3: return 'text-yellow-500';
    case 4: return 'text-green-500';
    case 5: return 'text-green-600';
    default: return 'text-gray-500';
  }
};

export const getMoodBorderColor = (rating: MoodRating): string => {
  switch (rating) {
    case 1: return 'border-red-500';
    case 2: return 'border-orange-400';
    case 3: return 'border-yellow-300';
    case 4: return 'border-green-300';
    case 5: return 'border-green-500';
    default: return 'border-gray-300';
  }
};

export const getMoodEmoji = (rating: MoodRating): string => {
  switch (rating) {
    case 1: return '😔';  // Sad but with empathy
    case 2: return '😕';  // Slightly worried
    case 3: return '😌';  // Calm and balanced
    case 4: return '😊';  // Genuinely happy
    case 5: return '🌟';  // Radiant and excellent
    default: return '❓';
  }
};

export const getMoodText = (rating: MoodRating): string => {
  switch (rating) {
    case 1: return 'Challenging';
    case 2: return 'Difficult';
    case 3: return 'Balanced';
    case 4: return 'Good';
    case 5: return 'Excellent';
    default: return 'Unknown';
  }
};

export const calculateMoodStats = (entries: JournalEntry[], emotionNames: Map<string, string>): MoodStats => {
  if (entries.length === 0) {
    return {
      averageMood: 0,
      mostFrequentEmotion: 'None',
      entryCount: 0
    };
  }

  // Calculate average mood
  const totalMood = entries.reduce((sum, entry) => sum + entry.moodRating, 0);
  const averageMood = Math.round((totalMood / entries.length) * 10) / 10;

  // Find most frequent emotion
  const emotionCounts = new Map<string, number>();
  entries.forEach(entry => {
    entry.emotions.forEach(emotion => {
      emotionCounts.set(emotion, (emotionCounts.get(emotion) || 0) + 1);
    });
  });

  let mostFrequentEmotion = 'None';
  let highestCount = 0;

  emotionCounts.forEach((count, emotion) => {
    if (count > highestCount) {
      highestCount = count;
      mostFrequentEmotion = emotionNames.get(emotion) || emotion;
    }
  });

  return {
    averageMood,
    mostFrequentEmotion,
    entryCount: entries.length
  };
};

export const getMoodCountsByRating = (entries: JournalEntry[]): Record<MoodRating, number> => {
  const counts: Record<MoodRating, number> = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0
  };

  entries.forEach(entry => {
    counts[entry.moodRating]++;
  });

  return counts;
};