import React from 'react';
import { supabase } from '../lib/supabase';

const SettingsPage: React.FC = () => {
  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="max-w-md mx-auto p-4 pb-20">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold mb-1 dark:text-white">Settings</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Manage your account
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
        <h2 className="text-lg font-medium mb-4 dark:text-white">Account</h2>
        <button
          onClick={handleSignOut}
          className="w-full py-2 px-4 border border-red-300 dark:border-red-500 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/30 transition-colors"
        >
          Sign Out
        </button>
      </div>
    </div>
  );
};

export default SettingsPage;