import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import MoodEntryCard from '../components/MoodEntryCard';
import MoodEntryForm from '../components/MoodEntryForm';
import { getDateOnly } from '../utils/dateUtils';

const HistoryPage: React.FC = () => {
  const { state } = useAppContext();
  const { journalEntries } = state;
  
  const [searchTerm, setSearchTerm] = useState('');
  const [editingEntry, setEditingEntry] = useState<string | null>(null);
  
  // Group entries by date
  const entriesByDate = useMemo(() => {
    const filtered = searchTerm 
      ? journalEntries.filter(entry => 
          entry.journalText.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.emotions.some(emotion => {
            const emotionObj = state.emotions.find(e => e.id === emotion);
            return emotionObj?.name.toLowerCase().includes(searchTerm.toLowerCase());
          }) ||
          entry.activities.some(activity => {
            const activityObj = state.activities.find(a => a.id === activity);
            return activityObj?.name.toLowerCase().includes(searchTerm.toLowerCase());
          })
        )
      : journalEntries;
    
    // Sort entries by date (newest first)
    const sorted = [...filtered].sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    
    // Group by date
    const grouped = new Map<string, typeof sorted>();
    sorted.forEach(entry => {
      const dateKey = getDateOnly(entry.date);
      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, []);
      }
      grouped.get(dateKey)!.push(entry);
    });
    
    return grouped;
  }, [journalEntries, searchTerm, state.emotions, state.activities]);
  
  const handleEdit = (entryId: string) => {
    setEditingEntry(entryId);
  };
  
  const handleEditComplete = () => {
    setEditingEntry(null);
  };

  return (
    <div className="max-w-md mx-auto p-4 pb-20">
      <div className="mb-4">
        <h1 className="text-2xl font-semibold mb-1 dark:text-white">Mood History</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Review your past entries
        </p>
      </div>
      
      <div className="mb-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search entries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 pl-8 text-sm border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-4 w-4 absolute left-2.5 top-2.5 text-gray-400" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
        </div>
      </div>
      
      {entriesByDate.size === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">
            {searchTerm 
              ? 'No entries found matching your search.' 
              : 'No mood entries yet. Start tracking your mood!'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {Array.from(entriesByDate.entries()).map(([date, entries]) => (
            <div key={date} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
              <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 border-b border-gray-200 dark:border-gray-600">
                <h2 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {new Date(date).toLocaleDateString('en-US', {
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric',
                  })}
                </h2>
              </div>
              <div className="divide-y divide-gray-100 dark:divide-gray-700">
                {entries.map(entry => (
                  <div key={entry.id} className="p-3">
                    {editingEntry === entry.id ? (
                      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="text-sm font-medium dark:text-white">Edit Entry</h3>
                          <button 
                            onClick={() => setEditingEntry(null)}
                            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 text-sm"
                          >
                            Cancel
                          </button>
                        </div>
                        <MoodEntryForm 
                          initialEntry={entry} 
                          onComplete={handleEditComplete} 
                        />
                      </div>
                    ) : (
                      <div className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <MoodEntryCard 
                          entry={entry} 
                          onEdit={() => handleEdit(entry.id)}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryPage;