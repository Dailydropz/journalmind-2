import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import MoodStats from '../components/MoodStats';
import MoodCalendar from '../components/MoodCalendar';
import { getDateOnly } from '../utils/dateUtils';

const AnalyticsPage: React.FC = () => {
  const { state } = useAppContext();
  const { journalEntries } = state;
  
  const [timeFrame, setTimeFrame] = useState<'week' | 'month' | 'all'>('week');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter entries based on selected time frame and search term
  const filteredEntries = useMemo(() => {
    const now = new Date();
    
    let filtered = journalEntries;
    
    // Apply time frame filter
    if (timeFrame === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(now.getDate() - 7);
      filtered = filtered.filter(entry => new Date(entry.date) >= weekAgo);
    } else if (timeFrame === 'month') {
      const monthAgo = new Date();
      monthAgo.setMonth(now.getMonth() - 1);
      filtered = filtered.filter(entry => new Date(entry.date) >= monthAgo);
    }
    
    // Apply search filter if there's a search term
    if (searchTerm) {
      filtered = filtered.filter(entry => {
        const searchLower = searchTerm.toLowerCase();
        return (
          entry.journalText.toLowerCase().includes(searchLower) ||
          entry.emotions.some(emotion => {
            const emotionObj = state.emotions.find(e => e.id === emotion);
            return emotionObj?.name.toLowerCase().includes(searchLower);
          }) ||
          entry.activities.some(activity => {
            const activityObj = state.activities.find(a => a.id === activity);
            return activityObj?.name.toLowerCase().includes(searchLower);
          })
        );
      });
    }
    
    return filtered;
  }, [journalEntries, timeFrame, searchTerm, state.emotions, state.activities]);
  
  // Handle calendar day click
  const handleDayClick = (dateStr: string) => {
    const entries = journalEntries.filter(
      entry => getDateOnly(entry.date) === dateStr
    );
    
    if (entries.length > 0) {
      window.location.hash = '#/history';
    }
  };

  return (
    <div className="max-w-md mx-auto p-4 pb-20">
      <div className="mb-4">
        <h1 className="text-2xl font-semibold mb-1 dark:text-white">Mood Analytics</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Visualize your mood patterns
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-white dark:bg-gray-800 p-2 rounded-lg shadow-sm">
          <div className="flex justify-between">
            <button
              onClick={() => setTimeFrame('week')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                timeFrame === 'week'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-300'
              }`}
            >
              Week
            </button>
            <button
              onClick={() => setTimeFrame('month')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                timeFrame === 'month'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-300'
              }`}
            >
              Month
            </button>
            <button
              onClick={() => setTimeFrame('all')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                timeFrame === 'all'
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-300'
              }`}
            >
              All Time
            </button>
          </div>
        </div>

        <div className="relative">
          <input
            type="text"
            placeholder="Search entries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 pl-8 text-sm border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-4 w-4 absolute left-2.5 top-2.5 text-gray-400" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
        </div>
        
        <MoodStats entries={filteredEntries} period={timeFrame} />
        
        <div>
          <h2 className="text-sm font-medium mb-2 dark:text-white">Monthly Overview</h2>
          <MoodCalendar 
            entries={journalEntries} 
            onDayClick={handleDayClick}
          />
          <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-1 text-center">
            Tap on a day with a mood entry to view details
          </p>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;