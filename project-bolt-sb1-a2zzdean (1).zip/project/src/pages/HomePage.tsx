import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import MoodEntryForm from '../components/MoodEntryForm';
import MoodEntryCard from '../components/MoodEntryCard';
import QuoteDisplay from '../components/QuoteDisplay';
import MotivationalText from '../components/MotivationalText';
import { getDateOnly, isToday } from '../utils/dateUtils';
import { JournalEntry } from '../types';
import { ChevronRight } from 'lucide-react';

const HomePage: React.FC = () => {
  const { state } = useAppContext();
  const { journalEntries } = state;
  
  const [showNewEntryForm, setShowNewEntryForm] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
  const [showGuide, setShowGuide] = useState(journalEntries.length === 0);

  // Get quotes from state
  const quotes = useMemo(() => state.quotes, [state.quotes]);
  
  // Check if user has already entered a mood today
  const todayEntry = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return journalEntries.find(entry => getDateOnly(entry.date) === today);
  }, [journalEntries]);
  
  // Get recent entries (last 3 days)
  const recentEntries = useMemo(() => {
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    
    return journalEntries
      .filter(entry => new Date(entry.date) >= threeDaysAgo)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [journalEntries]);

  const handleAddEntry = () => {
    setSelectedEntry(null);
    setShowNewEntryForm(true);
    setShowGuide(false);
  };
  
  const handleCancelEntry = () => {
    setSelectedEntry(null);
    setShowNewEntryForm(false);
  };
  
  const handleEntryComplete = () => {
    setSelectedEntry(null);
    setShowNewEntryForm(false);
  };

  const handleEntryClick = (entry: JournalEntry) => {
    if (!isToday(entry.date)) {
      const templateEntry = {
        ...entry,
        date: new Date().toISOString(),
      };
      setSelectedEntry(templateEntry);
      setShowNewEntryForm(true);
    }
  };

  const WelcomeGuide = () => (
    <div className="space-y-4 mb-6">
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-semibold mb-3">Welcome to JournalMind! 🌟</h2>
        <p className="text-blue-50 text-lg">Your personal space for emotional well-being and self-reflection.</p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm divide-y dark:divide-gray-700">
        <div className="p-6">
          <h3 className="text-xl font-medium mb-4 dark:text-white">Getting Started</h3>
          <ul className="space-y-4">
            <li className="flex items-start">
              <ChevronRight className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-700 dark:text-gray-300 font-medium">Track Your Mood</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Log your daily emotions using our intuitive mood tracker</p>
              </div>
            </li>
            <li className="flex items-start">
              <ChevronRight className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-700 dark:text-gray-300 font-medium">Journal Your Thoughts</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Express yourself with guided prompts and free-form writing</p>
              </div>
            </li>
            <li className="flex items-start">
              <ChevronRight className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-700 dark:text-gray-300 font-medium">Track Activities & Triggers</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Identify patterns in your emotional well-being</p>
              </div>
            </li>
            <li className="flex items-start">
              <ChevronRight className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-700 dark:text-gray-300 font-medium">View Insights</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Gain valuable insights from your mood patterns and trends</p>
              </div>
            </li>
          </ul>
        </div>

        <div className="p-6">
          <h3 className="text-xl font-medium mb-4 dark:text-white">Features</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="font-medium text-gray-700 dark:text-gray-300">Daily Check-ins</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Track your mood and energy levels</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="font-medium text-gray-700 dark:text-gray-300">Emotion Tags</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Label and track your feelings</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="font-medium text-gray-700 dark:text-gray-300">Activity Tracking</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Monitor mood influences</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="font-medium text-gray-700 dark:text-gray-300">Sleep Quality</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Track your rest patterns</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <button
            onClick={handleAddEntry}
            className="w-full bg-blue-600 dark:bg-blue-500 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors"
          >
            Create Your First Entry
          </button>
          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-3">
            Start your journey to better emotional awareness
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-md mx-auto p-4 pb-20">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold mb-1 dark:text-white">
          {journalEntries.length === 0 ? 'Welcome to JournalMind!' : 'How are you today?'}
        </h1>
        <MotivationalText />
      </div>
      
      {showGuide && <WelcomeGuide />}
      
      {!showGuide && <QuoteDisplay quotes={quotes} />}
      
      <div className="my-6">
        {showNewEntryForm ? (
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium dark:text-white">
                {selectedEntry ? 'Use as Template' : 'New Mood Entry'}
              </h2>
              <button 
                onClick={handleCancelEntry}
                className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              >
                Cancel
              </button>
            </div>
            <MoodEntryForm 
              onComplete={handleEntryComplete} 
              initialEntry={selectedEntry || undefined}
            />
          </div>
        ) : todayEntry ? (
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mb-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium dark:text-white">Today's Mood</h2>
              <button 
                onClick={handleAddEntry}
                className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 text-sm"
              >
                Add Another Entry
              </button>
            </div>
            <MoodEntryCard entry={todayEntry} />
          </div>
        ) : (
          <button
            onClick={handleAddEntry}
            className="w-full bg-blue-600 dark:bg-blue-500 text-white py-3 px-4 rounded-md font-medium hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors"
          >
            {journalEntries.length === 0 ? 'Create Your First Entry' : 'Log Today\'s Mood'}
          </button>
        )}
      </div>
      
      {recentEntries.length > 0 && !showGuide && (
        <div className="mt-4">
          <h2 className="text-lg font-medium mb-2 dark:text-white">Recent Entries</h2>
          <div className="grid grid-cols-1 gap-2">
            {recentEntries
              .filter(entry => !isToday(entry.date) || entry !== todayEntry)
              .slice(0, 3)
              .map(entry => (
                <div key={entry.id} className="transform transition-all hover:-translate-y-0.5">
                  <MoodEntryCard 
                    entry={entry}
                    isClickable={!isToday(entry.date)}
                    onClick={() => handleEntryClick(entry)}
                  />
                </div>
              ))}
          </div>
          {recentEntries.length > 3 && (
            <div className="text-center mt-2">
              <a 
                href="#/history" 
                className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
              >
                View all entries →
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default HomePage;