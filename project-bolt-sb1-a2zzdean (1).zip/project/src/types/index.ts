export type MoodRating = 1 | 2 | 3 | 4 | 5;

export type Emotion = {
  id: string;
  name: string;
};

export type Activity = {
  id: string;
  name: string;
};

export type JournalEntry = {
  id: string;
  date: string; // ISO string
  moodRating: MoodRating;
  journalText: string;
  emotions: string[]; // Array of emotion ids
  activities: string[]; // Array of activity ids
  createdAt: string; // ISO string
  energyLevel?: 'low' | 'medium' | 'high';
  sleepQuality?: number;
  physicalSymptoms?: string[];
  triggers?: string[];
};

export type MoodStats = {
  averageMood: number;
  mostFrequentEmotion: string;
  entryCount: number;
};

export type Quote = {
  id?: string;
  text: string;
  author: string;
};

export type QuoteDisplayProps = {
  quotes: Quote[];
  intervalMs?: number;
};

export type JournalPrompt = {
  id: string;
  text: string;
  forMood?: MoodRating;
};

export type AppSettings = {
  reminderEnabled: boolean;
  reminderTime: string; // 24h format, e.g. "09:00"
  showQuotes: boolean;
};