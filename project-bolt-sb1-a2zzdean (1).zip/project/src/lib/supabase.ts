import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim();
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing or invalid Supabase environment variables');
}

// Create the Supabase client with additional configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'X-Client-Info': 'journalmind'
    }
  },
  db: {
    schema: 'public'
  },
  // Add retries and timeout configuration
  realtime: {
    params: {
      eventsPerSecond: 2
    }
  }
});

// Enhanced error logging for auth state changes
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_IN') {
    console.log('User signed in successfully', { userId: session?.user?.id });
  } else if (event === 'SIGNED_OUT') {
    console.log('User signed out');
  } else if (event === 'TOKEN_REFRESHED') {
    console.log('Token refreshed successfully');
  } else if (event === 'USER_UPDATED') {
    console.log('User updated');
  } else if (event === 'USER_DELETED') {
    console.log('User deleted');
  } else {
    console.log('Auth state changed:', event);
  }
});

// Add a more robust connection test function with retries and detailed error logging
export const testSupabaseConnection = async () => {
  const maxRetries = 3;
  let retryCount = 0;

  const logError = (error: any, attempt: number) => {
    console.error(`Supabase connection attempt ${attempt} failed:`, {
      error: error?.message || error,
      errorCode: error?.code,
      statusCode: error?.status,
      details: error?.details,
      hint: error?.hint
    });
  };

  while (retryCount < maxRetries) {
    try {
      // First, check if we can get the session
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) {
        throw new Error(`Session check failed: ${sessionError.message}`);
      }

      // Then try a simple query to verify database access
      const { data, error } = await supabase
        .from('emotions')
        .select('count')
        .limit(1)
        .single();

      if (error) {
        throw error;
      }

      console.log('Supabase connection successful', {
        sessionStatus: sessionData?.session ? 'active' : 'no session',
        dbAccessible: true
      });
      return true;
    } catch (error) {
      retryCount++;
      logError(error, retryCount);
      
      if (retryCount === maxRetries) {
        console.error('Supabase connection test failed after all retries');
        return false;
      }
      // Wait before retrying (exponential backoff)
      await new Promise(resolve => setTimeout(resolve, Math.pow(2, retryCount) * 1000));
    }
  }
  return false;
};

// Initialize connection test
testSupabaseConnection()
  .then(isConnected => {
    if (!isConnected) {
      console.error('Failed to establish initial Supabase connection');
    }
  })
  .catch(error => {
    console.error('Unexpected error during connection test:', error);
  });