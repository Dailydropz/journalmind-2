import { useState, useEffect } from 'react';
import { Quote } from '../types';
import { supabase } from '../lib/supabase';

export function useQuote() {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchQuote = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // First check if we have a valid connection
      const isConnected = await supabase.auth.getSession();
      if (!isConnected) {
        throw new Error('No valid Supabase session');
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL?.trim()}/functions/v1/quotes`,
        {
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY?.trim()}`,
            'Content-Type': 'application/json'
          },
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to fetch quote: ${response.status} ${errorText}`);
      }

      const data = await response.json();
      setQuote(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch quote';
      console.error('Quote fetch error:', err);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQuote();
  }, []);

  return { quote, isLoading, error, refetch: fetchQuote };
}