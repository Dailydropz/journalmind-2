import { Emotion, Activity, JournalEntry, Quote, JournalPrompt, AppSettings } from '../types';

export const initialEmotions: Emotion[] = [
  { id: '1c582142-3f44-4c70-9f9b-e7c44c9f9d1e', name: 'Happy' },
  { id: '2d582142-3f44-4c70-9f9b-e7c44c9f9d1f', name: 'Calm' },
  { id: '3e582142-3f44-4c70-9f9b-e7c44c9f9d2a', name: 'Anxious' },
  { id: '4f582142-3f44-4c70-9f9b-e7c44c9f9d2b', name: 'Sad' },
  { id: '5a582142-3f44-4c70-9f9b-e7c44c9f9d2c', name: 'Angry' },
  { id: '6b582142-3f44-4c70-9f9b-e7c44c9f9d2d', name: 'Energetic' },
  { id: '7c582142-3f44-4c70-9f9b-e7c44c9f9d2e', name: 'Tired' },
  { id: '8d582142-3f44-4c70-9f9b-e7c44c9f9d2f', name: 'Grateful' },
  { id: '9e582142-3f44-4c70-9f9b-e7c44c9f9d3a', name: 'Stressed' },
  { id: '10f82142-3f44-4c70-9f9b-e7c44c9f9d3b', name: 'Peaceful' },
];

export const initialActivities: Activity[] = [
  { id: 'a1582142-3f44-4c70-9f9b-e7c44c9f9d4a', name: 'Work' },
  { id: 'b2582142-3f44-4c70-9f9b-e7c44c9f9d4b', name: 'Exercise' },
  { id: 'c3582142-3f44-4c70-9f9b-e7c44c9f9d4c', name: 'Social interaction' },
  { id: 'd4582142-3f44-4c70-9f9b-e7c44c9f9d4d', name: 'Family time' },
  { id: 'e5582142-3f44-4c70-9f9b-e7c44c9f9d4e', name: 'Sleep' },
  { id: 'f6582142-3f44-4c70-9f9b-e7c44c9f9d4f', name: 'Eating habits' },
  { id: 'g7582142-3f44-4c70-9f9b-e7c44c9f9d5a', name: 'Meditation' },
  { id: 'h8582142-3f44-4c70-9f9b-e7c44c9f9d5b', name: 'Time in nature' },
  { id: 'i9582142-3f44-4c70-9f9b-e7c44c9f9d5c', name: 'Screen time' },
  { id: 'j0582142-3f44-4c70-9f9b-e7c44c9f9d5d', name: 'Hobbies' },
];

export const initialJournalEntries: JournalEntry[] = [];

export const quotes: Quote[] = [
  {
    id: '1',
    text: 'You don\'t have to control your thoughts. You just have to stop letting them control you.',
    author: 'Dan Millman',
  },
  {
    id: '2',
    text: 'There is no path to happiness; happiness is the path.',
    author: 'Buddha',
  },
  {
    id: '3',
    text: 'What you\'re thinking is what you\'re becoming.',
    author: 'Muhammad Ali',
  },
  {
    id: '4',
    text: 'Happiness is not something ready-made. It comes from your own actions.',
    author: 'Dalai Lama',
  },
  {
    id: '5',
    text: 'The present moment is filled with joy and happiness. If you are attentive, you will see it.',
    author: 'Thich Nhat Hanh',
  },
  {
    id: '6',
    text: 'Every day is a new beginning. Take a deep breath and start again.',
    author: 'Unknown',
  },
  {
    id: '7',
    text: 'Your potential is endless. Go do what you were created to do.',
    author: 'Unknown',
  },
  {
    id: '8',
    text: 'The only way to do great work is to love what you do.',
    author: 'Steve Jobs',
  },
  {
    id: '9',
    text: 'Believe you can and you\'re halfway there.',
    author: 'Theodore Roosevelt',
  },
  {
    id: '10',
    text: 'The future belongs to those who believe in the beauty of their dreams.',
    author: 'Eleanor Roosevelt',
  }
];

export const journalPrompts: JournalPrompt[] = [
  {
    id: '1',
    text: 'What made you smile today?',
    forMood: 4,
  },
  {
    id: '2',
    text: 'What was challenging about today and how did you handle it?',
    forMood: 2,
  },
  {
    id: '3',
    text: 'Name three things you\'re grateful for right now.',
    forMood: 3,
  },
  {
    id: '4',
    text: 'What could make tomorrow better than today?',
  },
  {
    id: '5',
    text: 'How did you take care of yourself today?',
  },
  {
    id: '6',
    text: 'What small victory can you celebrate today?',
  },
  {
    id: '7',
    text: 'What positive change would you like to make in your life?',
  },
  {
    id: '8',
    text: 'What\'s one thing you\'re looking forward to?',
  },
  {
    id: '9',
    text: 'How can you show yourself more compassion today?',
  },
  {
    id: '10',
    text: 'What strength did you discover about yourself recently?',
  }
];

export const initialSettings: AppSettings = {
  reminderEnabled: false,
  reminderTime: '20:00',
  showQuotes: true,
};