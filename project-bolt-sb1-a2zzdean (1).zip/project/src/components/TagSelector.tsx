import React from 'react';

interface Tag {
  id: string;
  name: string;
}

interface TagSelectorProps {
  title: string;
  tags: Tag[];
  selectedTags: string[];
  onChange: (selectedTags: string[]) => void;
  maxSelections?: number;
}

const TagSelector: React.FC<TagSelectorProps> = ({
  title,
  tags,
  selectedTags,
  onChange,
  maxSelections = 5,
}) => {
  const handleTagClick = (tagId: string) => {
    if (selectedTags.includes(tagId)) {
      onChange(selectedTags.filter((id) => id !== tagId));
    } else if (selectedTags.length < maxSelections) {
      onChange([...selectedTags, tagId]);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <h3 className="text-md font-medium text-gray-700 dark:text-gray-300">{title}</h3>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {selectedTags.length}/{maxSelections}
        </span>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <button
            key={tag.id}
            type="button"
            onClick={() => handleTagClick(tag.id)}
            className={`px-3 py-1 rounded-full text-sm transition-colors ${
              selectedTags.includes(tag.id)
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-blue-700'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            {tag.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TagSelector;