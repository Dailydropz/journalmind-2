import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import HomePage from '../pages/HomePage';
import HistoryPage from '../pages/HistoryPage';
import AnalyticsPage from '../pages/AnalyticsPage';
import SettingsPage from '../pages/SettingsPage';
import AuthPage from '../pages/AuthPage';
import Navigation from './Navigation';

function AppRouter() {
  const [currentRoute, setCurrentRoute] = useState('/');
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      // Reset route to home when auth state changes
      if (session) {
        window.location.hash = '/';
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const handleHashChange = () => {
      setCurrentRoute(window.location.hash.replace('#', '') || '/');
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    if (loading) {
      return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-gray-600 dark:text-gray-400">Loading...</div>
        </div>
      );
    }

    if (!session) {
      return <AuthPage />;
    }

    switch (currentRoute) {
      case '/':
        return <HomePage />;
      case '/history':
        return <HistoryPage />;
      case '/analytics':
        return <AnalyticsPage />;
      case '/settings':
        return <SettingsPage />;
      default:
        return <HomePage />;
    }
  };

  useEffect(() => {
    const pageTitles: Record<string, string> = {
      '/': 'JournalMind | Daily Mood Tracking',
      '/history': 'JournalMind | History',
      '/analytics': 'JournalMind | Analytics',
      '/settings': 'JournalMind | Settings',
    };

    document.title = pageTitles[currentRoute] || 'JournalMind';

    const titleElement = document.querySelector('title[data-default]');
    if (titleElement) {
      titleElement.textContent = pageTitles[currentRoute] || 'JournalMind';
    }
  }, [currentRoute]);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      {renderPage()}
      {session && <Navigation currentRoute={currentRoute} />}
    </div>
  );
}

export default AppRouter;