import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
  slot: string;
  format?: 'auto' | 'fluid' | 'rectangle';
  layout?: 'in-article' | 'display';
}

const AdBanner: React.FC<AdBannerProps> = ({ slot, format = 'auto', layout = 'display' }) => {
  const adRef = useRef<HTMLDivElement>(null);
  const isAdLoaded = useRef(false);

  useEffect(() => {
    // Only try to load ad if it hasn't been loaded yet
    if (adRef.current && !isAdLoaded.current) {
      try {
        // Wait for the container to have a width
        const observer = new ResizeObserver((entries) => {
          const [entry] = entries;
          if (entry.contentRect.width > 0) {
            // Disconnect observer once we have width
            observer.disconnect();
            
            // Push ad only if not already loaded
            if (!isAdLoaded.current) {
              ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
              isAdLoaded.current = true;
            }
          }
        });

        observer.observe(adRef.current);

        return () => {
          observer.disconnect();
        };
      } catch (error) {
        console.error('Error loading AdSense:', error);
      }
    }
  }, []);

  return (
    <div ref={adRef} className="w-full flex justify-center my-4">
      <ins
        className="adsbygoogle"
        style={{ 
          display: 'block',
          minWidth: '300px',
          minHeight: '250px',
          width: '100%'
        }}
        data-ad-client="ca-pub-5123601661798924"
        data-ad-slot={slot}
        data-ad-format={format}
        data-ad-layout={layout}
        data-full-width-responsive="true"
      />
    </div>
  );
};

export default AdBanner;