import React from 'react';
import { Brain } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <a 
      href="#/" 
      className="flex items-center space-x-3 text-gray-900 dark:text-white group transition-transform hover:scale-[1.02]"
      aria-label="JournalMind - Home"
    >
      <div className="relative">
        <Brain 
          size={36} 
          className="text-blue-600 dark:text-blue-400 transition-colors group-hover:text-blue-700 dark:group-hover:text-blue-300" 
          strokeWidth={1.5}
        />
        <div className="absolute -inset-1 bg-blue-100 dark:bg-blue-900/30 rounded-lg -z-10 opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      <div className="flex flex-col">
        <span className="text-2xl font-bold tracking-tight">JournalMind</span>
        <span className="text-xs text-gray-600 dark:text-gray-400 tracking-wider">Your Mental Wellness Journal</span>
      </div>
    </a>
  );
};

export default Logo;