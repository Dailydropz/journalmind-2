import React, { useMemo } from 'react';
import { JournalEntry } from '../types';
import { calculateMoodStats, getMoodCountsByRating, getMoodEmoji, getMoodColor } from '../utils/moodUtils';
import { useAppContext } from '../context/AppContext';

interface MoodStatsProps {
  entries: JournalEntry[];
  period: 'week' | 'month' | 'all';
}

const MoodStats: React.FC<MoodStatsProps> = ({ entries, period }) => {
  const { state } = useAppContext();

  const emotionNames = useMemo(() => {
    return new Map(state.emotions.map(e => [e.id, e.name]));
  }, [state.emotions]);

  const stats = useMemo(() => {
    return calculateMoodStats(entries, emotionNames);
  }, [entries, emotionNames]);

  const moodCounts = useMemo(() => {
    return getMoodCountsByRating(entries);
  }, [entries]);

  // Calculate energy level distribution
  const energyLevelStats = useMemo(() => {
    const counts = { low: 0, medium: 0, high: 0, total: 0 };
    entries.forEach(entry => {
      if (entry.energyLevel) {
        counts[entry.energyLevel]++;
        counts.total++;
      }
    });
    return counts;
  }, [entries]);

  // Calculate average sleep quality
  const sleepStats = useMemo(() => {
    const sleepEntries = entries.filter(entry => entry.sleepQuality !== undefined);
    const total = sleepEntries.reduce((sum, entry) => sum + (entry.sleepQuality || 0), 0);
    return {
      average: sleepEntries.length > 0 ? Math.round((total / sleepEntries.length) * 10) / 10 : 0,
      count: sleepEntries.length
    };
  }, [entries]);

  const periodText = useMemo(() => {
    switch (period) {
      case 'week': return 'this week';
      case 'month': return 'this month';
      case 'all': return 'overall';
      default: return '';
    }
  }, [period]);

  // Calculate mood trend
  const moodTrend = useMemo(() => {
    if (entries.length < 2) return 'stable';
    
    const sortedEntries = [...entries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    const recentMoods = sortedEntries.slice(-3);
    const avgRecent = recentMoods.reduce((sum, entry) => sum + entry.moodRating, 0) / recentMoods.length;
    const avgOverall = stats.averageMood;
    
    if (avgRecent > avgOverall + 0.5) return 'improving';
    if (avgRecent < avgOverall - 0.5) return 'declining';
    return 'stable';
  }, [entries, stats.averageMood]);

  // Calculate streak
  const currentStreak = useMemo(() => {
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const hasEntry = entries.some(entry => entry.date.startsWith(dateStr));
      if (hasEntry) {
        streak++;
      } else if (streak > 0) {
        break;
      }
    }
    
    return streak;
  }, [entries]);

  if (entries.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 text-center">
        <p className="text-gray-500 dark:text-gray-400">No data available for {periodText}</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
      <h3 className="font-semibold text-gray-800 dark:text-white mb-4">Mood Summary {periodText}</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Average Mood</div>
          <div className="flex items-center">
            <span className="text-2xl font-bold mr-2 dark:text-white">{stats.averageMood}</span>
            <span className="text-xl">{getMoodEmoji(Math.round(stats.averageMood) as any)}</span>
          </div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Current Streak</div>
          <div className="flex items-center">
            <span className="text-2xl font-bold mr-2 dark:text-white">{currentStreak}</span>
            <span className="text-xl">🔥</span>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Energy Level Stats */}
        <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Energy Levels</h4>
          <div className="space-y-2">
            {['high', 'medium', 'low'].map(level => {
              const count = energyLevelStats[level];
              const percentage = energyLevelStats.total > 0 
                ? (count / energyLevelStats.total) * 100 
                : 0;
              
              return (
                <div key={level} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="capitalize text-gray-600 dark:text-gray-300">{level}</span>
                    <span className="text-gray-500 dark:text-gray-400">{percentage.toFixed(1)}%</span>
                  </div>
                  <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        level === 'high' ? 'bg-green-500' :
                        level === 'medium' ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sleep Quality Stats */}
        <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Sleep Quality</h4>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-bold dark:text-white">{sleepStats.average}</span>
            <span className="text-sm text-gray-500 dark:text-gray-400">/ 10</span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Based on {sleepStats.count} entries
          </p>
        </div>
      </div>
      
      <div className="mt-6">
        <h4 className="text-lg font-medium mb-4 dark:text-white">Mood Distribution</h4>
        <div className="space-y-4">
          {[5, 4, 3, 2, 1].map(mood => {
            const count = moodCounts[mood as keyof typeof moodCounts];
            const percentage = entries.length > 0 ? (count / entries.length) * 100 : 0;
            
            return (
              <div key={mood} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{getMoodEmoji(mood as any)}</span>
                    <span className="text-sm dark:text-gray-300">{count} entries</span>
                  </div>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {percentage.toFixed(1)}%
                  </span>
                </div>
                <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${getMoodColor(mood as any)} transition-all duration-500`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default MoodStats;