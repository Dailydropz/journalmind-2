import React from 'react';
import Logo from './Logo';

const Header: React.FC = () => {
  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-md mx-auto px-4 py-4">
        <Logo />
      </div>
    </header>
  );
};

export default Header;