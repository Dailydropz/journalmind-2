import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { getDateOnly } from '../utils/dateUtils';

const motivationalPhrases = {
  1: [ // Very Negative
    "Tomorrow is a new beginning",
    "It's okay not to be okay",
    "Small steps forward are still progress",
    "You're stronger than you know",
    "This too shall pass",
    "Every storm runs out of rain",
    "Your struggles are shaping your strength",
    "Better days are coming",
    "You've overcome difficult times before",
    "Take it one moment at a time"
  ],
  2: [ // Negative
    "Every day is a fresh start",
    "You've got this",
    "Focus on what you can control",
    "Take it one step at a time",
    "Better days are coming",
    "Progress over perfection",
    "Small improvements add up",
    "Your effort matters",
    "Keep moving forward",
    "Trust your journey"
  ],
  3: [ // Neutral
    "Keep moving forward",
    "You're doing great",
    "Stay present, stay focused",
    "Every moment counts",
    "Embrace the journey",
    "You're making progress",
    "Keep building momentum",
    "Your efforts will pay off",
    "Stay consistent, stay strong",
    "Each day is an opportunity"
  ],
  4: [ // Positive
    "Keep that positive energy flowing",
    "You're on the right track",
    "Your positivity is inspiring",
    "Keep shining bright",
    "Maintain this wonderful momentum",
    "Your attitude is everything",
    "You're making great progress",
    "Keep believing in yourself",
    "Your energy is contagious",
    "Success looks good on you"
  ],
  5: [ // Very Positive
    "Your happiness is contagious",
    "Keep spreading those good vibes",
    "You're absolutely crushing it",
    "Your positive energy lights up the room",
    "Keep that amazing spirit going",
    "You're unstoppable",
    "Your potential is limitless",
    "You're an inspiration",
    "Keep soaring higher",
    "Your success inspires others"
  ],
  default: [
    "Track your mood and reflect on your day",
    "Every day is a new opportunity",
    "Your feelings matter",
    "Take a moment for self-reflection",
    "Start your journey of self-discovery",
    "Your well-being is important",
    "Make today count",
    "Embrace the present moment",
    "Your journey matters",
    "Build your best life"
  ]
};

const MotivationalText: React.FC = () => {
  const { state } = useAppContext();
  const [currentPhrase, setCurrentPhrase] = useState('');
  const [lastUpdateDate, setLastUpdateDate] = useState('');

  useEffect(() => {
    const updatePhrase = () => {
      // Get yesterday's date
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = getDateOnly(yesterday.toISOString());

      // Find yesterday's entry
      const yesterdayEntry = state.journalEntries.find(
        entry => getDateOnly(entry.date) === yesterdayStr
      );

      // Get today's date
      const today = new Date();
      const todayStr = getDateOnly(today.toISOString());

      // Only update if it's a new day
      if (todayStr !== lastUpdateDate) {
        // Get the appropriate phrases based on yesterday's mood
        const phrases = yesterdayEntry 
          ? motivationalPhrases[yesterdayEntry.moodRating] 
          : motivationalPhrases.default;

        // Use today's date to pick a consistent phrase for the day
        const dateNum = parseInt(todayStr.replace(/-/g, ''), 10);
        const phraseIndex = dateNum % phrases.length;

        setCurrentPhrase(phrases[phraseIndex]);
        setLastUpdateDate(todayStr);
      }
    };

    // Update immediately
    updatePhrase();

    // Set up interval to check for date changes
    const interval = setInterval(updatePhrase, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [state.journalEntries, lastUpdateDate]);

  return (
    <p className="text-gray-600 dark:text-gray-400 animate-fade-in">
      {currentPhrase}
    </p>
  );
};

export default MotivationalText;