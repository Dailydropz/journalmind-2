import React, { useState } from 'react';
import { JournalEntry, MoodRating } from '../types';
import { useAppContext } from '../context/AppContext';
import MoodInput from './MoodInput';
import TagSelector from './TagSelector';
import JournalTextArea from './JournalTextArea';
import { supabase } from '../lib/supabase';

interface MoodEntryFormProps {
  onComplete?: () => void;
  initialEntry?: JournalEntry;
}

const MoodEntryForm: React.FC<MoodEntryFormProps> = ({ 
  onComplete,
  initialEntry 
}) => {
  const { state, addEntry, updateEntry } = useAppContext();
  
  const [mood, setMood] = useState<MoodRating | null>(initialEntry?.moodRating || null);
  const [journalText, setJournalText] = useState(initialEntry?.journalText || '');
  const [energyLevel, setEnergyLevel] = useState<'low' | 'medium' | 'high'>(initialEntry?.energyLevel || 'medium');
  const [sleepQuality, setSleepQuality] = useState<number>(initialEntry?.sleepQuality || 5);
  const [physicalSymptoms, setPhysicalSymptoms] = useState<string[]>(initialEntry?.physicalSymptoms || []);
  const [triggers, setTriggers] = useState<string[]>(initialEntry?.triggers || []);
  
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>(() => {
    if (!initialEntry?.emotions) return [];
    return initialEntry.emotions
      .map(emotionName => {
        const emotion = state.emotions.find(e => e.name === emotionName);
        return emotion?.id || '';
      })
      .filter(Boolean);
  });
  
  const [selectedActivities, setSelectedActivities] = useState<string[]>(() => {
    if (!initialEntry?.activities) return [];
    return initialEntry.activities
      .map(activityName => {
        const activity = state.activities.find(a => a.name === activityName);
        return activity?.id || '';
      })
      .filter(Boolean);
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const isEditing = !!initialEntry;
  const isFormValid = mood !== null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!mood || isSubmitting) return;
    
    setIsSubmitting(true);
    setError(null);
    
    try {
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError) throw authError;
      if (!user) throw new Error('Not authenticated');

      const entryData = {
        user_id: user.id,
        mood_rating: mood,
        journal_text: journalText.trim(),
        date: new Date().toISOString(),
        energy_level: energyLevel,
        sleep_quality: sleepQuality,
        physical_symptoms: physicalSymptoms,
        triggers,
      };

      let entryId: string;

      if (isEditing && initialEntry) {
        const { data: updatedEntry, error: updateError } = await supabase
          .from('journal_entries')
          .update(entryData)
          .eq('id', initialEntry.id)
          .select()
          .single();

        if (updateError) throw updateError;
        entryId = initialEntry.id;

        await supabase
          .from('entry_emotions')
          .delete()
          .eq('entry_id', entryId);

        await supabase
          .from('entry_activities')
          .delete()
          .eq('entry_id', entryId);

      } else {
        const { data: newEntry, error: insertError } = await supabase
          .from('journal_entries')
          .insert(entryData)
          .select()
          .single();

        if (insertError) throw insertError;
        if (!newEntry) throw new Error('Failed to create entry');
        entryId = newEntry.id;
      }

      if (selectedEmotions.length > 0) {
        const emotionInserts = selectedEmotions
          .filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))
          .map(emotionId => ({
            entry_id: entryId,
            emotion_id: emotionId
          }));

        if (emotionInserts.length > 0) {
          const { error: emotionsError } = await supabase
            .from('entry_emotions')
            .insert(emotionInserts);

          if (emotionsError) throw emotionsError;
        }
      }

      if (selectedActivities.length > 0) {
        const activityInserts = selectedActivities
          .filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))
          .map(activityId => ({
            entry_id: entryId,
            activity_id: activityId
          }));

        if (activityInserts.length > 0) {
          const { error: activitiesError } = await supabase
            .from('entry_activities')
            .insert(activityInserts);

          if (activitiesError) throw activitiesError;
        }
      }

      const { data: completeEntry, error: fetchError } = await supabase
        .from('journal_entries')
        .select(`
          *,
          entry_emotions (
            emotions (id, name)
          ),
          entry_activities (
            activities (id, name)
          )
        `)
        .eq('id', entryId)
        .single();

      if (fetchError) throw fetchError;
      if (!completeEntry) throw new Error('Failed to fetch complete entry');

      const formattedEntry: JournalEntry = {
        id: completeEntry.id,
        date: completeEntry.date,
        moodRating: completeEntry.mood_rating,
        journalText: completeEntry.journal_text,
        emotions: completeEntry.entry_emotions.map((ee: any) => ee.emotions.name),
        activities: completeEntry.entry_activities.map((ea: any) => ea.activities.name),
        createdAt: completeEntry.created_at,
        energyLevel: completeEntry.energy_level,
        sleepQuality: completeEntry.sleep_quality,
        physicalSymptoms: completeEntry.physical_symptoms,
        triggers: completeEntry.triggers
      };

      if (isEditing) {
        updateEntry(formattedEntry);
      } else {
        addEntry(formattedEntry);
      }

      if (onComplete) {
        onComplete();
      }

      // Navigate to history page after successful entry
      window.location.hash = '/history';
    } catch (error) {
      console.error('Error saving entry:', error);
      setError(error instanceof Error ? error.message : 'Failed to save entry');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="p-4 text-sm rounded-lg text-red-800 bg-red-100 dark:bg-red-900/50 dark:text-red-400">
          {error}
        </div>
      )}

      <MoodInput selectedMood={mood} onChange={setMood} />
      
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Energy Level
        </label>
        <div className="flex space-x-4">
          {(['low', 'medium', 'high'] as const).map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setEnergyLevel(level)}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                energyLevel === level
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              {level.charAt(0).toUpperCase() + level.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Sleep Quality (Previous Night)
        </label>
        <input
          type="range"
          min="1"
          max="10"
          value={sleepQuality}
          onChange={(e) => setSleepQuality(parseInt(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
        />
        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
          <span>Poor</span>
          <span>Excellent</span>
        </div>
      </div>
      
      <TagSelector
        title="How are you feeling?"
        tags={state.emotions}
        selectedTags={selectedEmotions}
        onChange={setSelectedEmotions}
        maxSelections={3}
      />
      
      <TagSelector
        title="What influenced your mood?"
        tags={state.activities}
        selectedTags={selectedActivities}
        onChange={setSelectedActivities}
        maxSelections={3}
      />

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Physical Symptoms
        </label>
        <input
          type="text"
          value={physicalSymptoms.join(', ')}
          onChange={(e) => setPhysicalSymptoms(e.target.value.split(',').map(s => s.trim()))}
          placeholder="Headache, fatigue, etc. (comma-separated)"
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Potential Triggers
        </label>
        <input
          type="text"
          value={triggers.join(', ')}
          onChange={(e) => setTriggers(e.target.value.split(',').map(s => s.trim()))}
          placeholder="Work stress, relationship, etc. (comma-separated)"
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
        />
      </div>
      
      <JournalTextArea 
        value={journalText} 
        onChange={setJournalText} 
        maxLength={2000}
        currentMood={mood}
        prompts={state.journalPrompts}
      />
      
      <div className="pt-4">
        <button
          type="submit"
          disabled={!isFormValid || isSubmitting}
          className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
            isFormValid && !isSubmitting
              ? 'bg-blue-600 dark:bg-blue-500 text-white hover:bg-blue-700 dark:hover:bg-blue-600'
              : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
          }`}
        >
          {isSubmitting 
            ? 'Saving...' 
            : isEditing 
              ? 'Update Entry' 
              : 'Save Entry'}
        </button>
      </div>
    </form>
  );
};

export default MoodEntryForm;