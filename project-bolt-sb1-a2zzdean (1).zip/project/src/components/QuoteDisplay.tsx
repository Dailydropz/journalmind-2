import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { QuoteDisplayProps } from '../types';

const QuoteDisplay: React.FC<QuoteDisplayProps> = ({ 
  quotes, 
  intervalMs = 5000 
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const intervalRef = useRef<number>();

  const rotateQuote = useCallback(() => {
    if (quotes.length <= 1) return;
    
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % quotes.length);
      setIsTransitioning(false);
    }, 300); // Match transition duration
  }, [quotes.length]);

  useEffect(() => {
    if (quotes.length <= 1) return;

    intervalRef.current = window.setInterval(rotateQuote, intervalMs);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [rotateQuote, intervalMs, quotes.length]);

  if (!quotes.length) {
    return (
      <div 
        role="alert"
        className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-center text-gray-500 dark:text-gray-400"
      >
        No quotes available
      </div>
    );
  }

  const currentQuote = quotes[currentIndex];

  return (
    <div 
      className="relative bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm"
      role="region"
      aria-label="Quote Display"
    >
      <div className={`
        transition-opacity duration-300 ease-in-out
        ${isTransitioning ? 'opacity-0' : 'opacity-100'}
      `}>
        <blockquote className="relative">
          <p 
            className="text-lg text-gray-700 dark:text-gray-300 italic mb-4"
            aria-label="Quote text"
          >
            "{currentQuote.text}"
          </p>
          <footer>
            <cite 
              className="block text-right text-sm text-gray-500 dark:text-gray-400"
              aria-label="Quote author"
            >
              — {currentQuote.author}
            </cite>
          </footer>
        </blockquote>
      </div>

      {quotes.length > 1 && (
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-1 mt-4">
          {quotes.map((_, index) => (
            <div
              key={index}
              className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${
                index === currentIndex
                  ? 'bg-blue-500 dark:bg-blue-400'
                  : 'bg-gray-300 dark:bg-gray-600'
              }`}
              role="presentation"
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default QuoteDisplay;