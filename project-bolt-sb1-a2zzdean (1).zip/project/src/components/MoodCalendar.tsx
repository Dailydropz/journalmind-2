import React, { useMemo } from 'react';
import { JournalEntry } from '../types';
import { getCurrentMonthDates, getDateOnly } from '../utils/dateUtils';
import { getMoodColor } from '../utils/moodUtils';

interface MoodCalendarProps {
  entries: JournalEntry[];
  onDayClick?: (date: string) => void;
}

const MoodCalendar: React.FC<MoodCalendarProps> = ({ entries, onDayClick }) => {
  const currentMonth = useMemo(() => getCurrentMonthDates(), []);
  const monthName = currentMonth[0].toLocaleString('default', { month: 'short' });
  const year = currentMonth[0].getFullYear();
  
  // Group entries by date
  const entriesByDate = useMemo(() => {
    const map = new Map<string, JournalEntry>();
    entries.forEach(entry => {
      const dateKey = getDateOnly(entry.date);
      map.set(dateKey, entry);
    });
    return map;
  }, [entries]);

  // Get day of week for first day of month (0 = Sunday, 6 = Saturday)
  const firstDayOfWeek = currentMonth[0].getDay();
  
  // Create blank cells for days before the 1st of the month
  const blanks = Array(firstDayOfWeek).fill(null);
  
  // Calendar days including blanks
  const calendarDays = [...blanks, ...currentMonth];
  
  // Split into weeks
  const weeks: (Date | null)[][] = [];
  for (let i = 0; i < calendarDays.length; i += 7) {
    weeks.push(calendarDays.slice(i, i + 7));
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-2">
      <div className="flex justify-between items-center mb-1 px-1">
        <h3 className="font-medium text-gray-800 dark:text-white text-xs">
          {monthName} {year}
        </h3>
        <div className="flex items-center space-x-2 text-[10px] text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
            <span>Low</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            <span>High</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-7 text-center text-[10px] text-gray-500 dark:text-gray-400">
        <div>S</div>
        <div>M</div>
        <div>T</div>
        <div>W</div>
        <div>T</div>
        <div>F</div>
        <div>S</div>
      </div>
      
      <div className="mt-0.5">
        {weeks.map((week, weekIndex) => (
          <div key={weekIndex} className="grid grid-cols-7 gap-0.5">
            {week.map((day, dayIndex) => {
              if (!day) {
                return <div key={`empty-${dayIndex}`} className="h-5" />;
              }
              
              const dateKey = day.toISOString().split('T')[0];
              const entry = entriesByDate.get(dateKey);
              const isToday = new Date().toISOString().split('T')[0] === dateKey;
              
              return (
                <button
                  key={dateKey}
                  onClick={() => onDayClick && onDayClick(dateKey)}
                  className={`
                    flex items-center justify-center h-5 w-full text-[10px]
                    ${isToday ? 'ring-1 ring-blue-400 dark:ring-blue-500' : ''}
                    ${entry ? getMoodColor(entry.moodRating) : 'hover:bg-gray-100 dark:hover:bg-gray-700'}
                    ${entry ? 'text-white font-medium' : 'text-gray-700 dark:text-gray-300'}
                    transition-colors rounded-sm
                  `}
                >
                  {day.getDate()}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MoodCalendar;