import React from 'react';
import { MoodRating } from '../types';
import { getMoodEmoji, getMoodText, getMoodColor } from '../utils/moodUtils';

interface MoodInputProps {
  selectedMood: MoodRating | null;
  onChange: (mood: MoodRating) => void;
}

const MoodInput: React.FC<MoodInputProps> = ({ selectedMood, onChange }) => {
  const moods: MoodRating[] = [1, 2, 3, 4, 5];

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
        How are you feeling today?
      </h3>
      
      <div className="grid grid-cols-5 gap-3">
        {moods.map((mood) => (
          <button
            key={mood}
            onClick={() => onChange(mood)}
            type="button"
            className={`
              flex flex-col items-center justify-center p-4 rounded-lg transition-all duration-200
              ${selectedMood === mood 
                ? `${getMoodColor(mood)} bg-opacity-20 dark:bg-opacity-30 ring-2 ring-opacity-50 ring-current transform scale-105` 
                : 'hover:bg-gray-50 dark:hover:bg-gray-700'
              }
            `}
            aria-label={`Select mood: ${getMoodText(mood)}`}
            aria-pressed={selectedMood === mood}
          >
            <span className="text-3xl mb-2 transition-transform duration-200 transform hover:scale-110">
              {getMoodEmoji(mood)}
            </span>
            <span className={`text-sm font-medium ${
              selectedMood === mood 
                ? 'text-current' 
                : 'text-gray-700 dark:text-gray-300'
            }`}>
              {getMoodText(mood)}
            </span>
          </button>
        ))}
      </div>
      
      {selectedMood && (
        <div className="mt-4 space-y-2">
          <div className={`h-1.5 rounded-full ${getMoodColor(selectedMood)}`} />
          <p className="text-sm text-center text-gray-600 dark:text-gray-400">
            You selected: {getMoodText(selectedMood)}
          </p>
        </div>
      )}
    </div>
  );
};

export default MoodInput;