import React from 'react';
import { JournalEntry } from '../types';
import { formatDate, formatTime, getRelativeDayText } from '../utils/dateUtils';
import { getMoodEmoji, getMoodColor, getMoodText } from '../utils/moodUtils';
import { useAppContext } from '../context/AppContext';

interface MoodEntryCardProps {
  entry: JournalEntry;
  onEdit?: () => void;
  onClick?: () => void;
  isClickable?: boolean;
}

const MoodEntryCard: React.FC<MoodEntryCardProps> = ({ 
  entry, 
  onEdit, 
  onClick,
  isClickable = false 
}) => {
  const { state, deleteEntry } = useAppContext();
  
  const emotionNames = new Map(state.emotions.map(e => [e.id, e.name]));
  const activityNames = new Map(state.activities.map(a => [a.id, a.name]));
  
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this entry?')) {
      deleteEntry(entry.id);
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) onEdit();
  };

  return (
    <div 
      className={`border-l-4 ${getMoodColor(entry.moodRating)} bg-white dark:bg-gray-800 rounded-md shadow-sm p-4 transition-all ${
        isClickable 
          ? 'cursor-pointer hover:shadow-md hover:transform hover:scale-[1.02] active:scale-[0.98]' 
          : 'hover:shadow-md'
      }`}
      onClick={isClickable && onClick ? onClick : undefined}
    >
      <div className="flex justify-between items-start mb-2">
        <div>
          <div className="flex items-center">
            <span className="text-xl mr-2">{getMoodEmoji(entry.moodRating)}</span>
            <span className="font-medium dark:text-white">{getMoodText(entry.moodRating)}</span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {getRelativeDayText(entry.date)} at {formatTime(entry.date)}
          </p>
        </div>
        
        <div className="flex space-x-2">
          {onEdit && (
            <button
              onClick={handleEdit}
              className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-1 rounded transition-colors"
              aria-label="Edit entry"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
          )}
          <button
            onClick={handleDelete}
            className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 p-1 rounded transition-colors"
            aria-label="Delete entry"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              <line x1="10" y1="11" x2="10" y2="17"></line>
              <line x1="14" y1="11" x2="14" y2="17"></line>
            </svg>
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {entry.energyLevel && (
          <div className="flex items-center text-sm">
            <span className="text-gray-600 dark:text-gray-400 mr-2">Energy Level:</span>
            <span className="font-medium dark:text-white capitalize">{entry.energyLevel}</span>
          </div>
        )}

        {entry.sleepQuality && (
          <div className="flex items-center text-sm">
            <span className="text-gray-600 dark:text-gray-400 mr-2">Sleep Quality:</span>
            <span className="font-medium dark:text-white">{entry.sleepQuality}/10</span>
          </div>
        )}

        {entry.physicalSymptoms && entry.physicalSymptoms.length > 0 && (
          <div className="text-sm">
            <span className="text-gray-600 dark:text-gray-400">Physical Symptoms:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {entry.physicalSymptoms.map((symptom, index) => (
                <span 
                  key={index}
                  className="px-2 py-0.5 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-xs rounded-full"
                >
                  {symptom}
                </span>
              ))}
            </div>
          </div>
        )}

        {entry.triggers && entry.triggers.length > 0 && (
          <div className="text-sm">
            <span className="text-gray-600 dark:text-gray-400">Triggers:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {entry.triggers.map((trigger, index) => (
                <span 
                  key={index}
                  className="px-2 py-0.5 bg-yellow-50 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 text-xs rounded-full"
                >
                  {trigger}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {entry.journalText && (
        <p className="text-gray-700 dark:text-gray-300 my-3 whitespace-pre-line">{entry.journalText}</p>
      )}
      
      <div className="flex flex-wrap gap-1 mt-3">
        {entry.emotions.map(emotionId => (
          <span 
            key={emotionId} 
            className="px-2 py-0.5 bg-blue-50 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded-full"
          >
            {emotionNames.get(emotionId) || emotionId}
          </span>
        ))}
        
        {entry.activities.map(activityId => (
          <span 
            key={activityId} 
            className="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-full"
          >
            {activityNames.get(activityId) || activityId}
          </span>
        ))}
      </div>
    </div>
  );
};

export default MoodEntryCard;