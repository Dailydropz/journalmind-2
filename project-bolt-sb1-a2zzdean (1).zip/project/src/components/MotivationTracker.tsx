import React, { useState, useEffect } from 'react';
import { supabase, testSupabaseConnection } from '../lib/supabase';
import type { MotivationAction, MotivationLog } from '../types';
import MotivationActionForm from './MotivationActionForm';
import MotivationStats from './MotivationStats';

const MotivationTracker: React.FC = () => {
  const [actions, setActions] = useState<MotivationAction[]>([]);
  const [logs, setLogs] = useState<MotivationLog[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // First, test the Supabase connection
      const isConnected = await testSupabaseConnection();
      if (!isConnected) {
        throw new Error('Unable to connect to the database. Please check your internet connection.');
      }

      // Check authentication
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setError('Please sign in to access the motivation tracker');
        setLoading(false);
        return;
      }

      // Fetch data with detailed error handling
      const [actionsResponse, logsResponse] = await Promise.all([
        supabase
          .from('motivation_actions')
          .select('*')
          .order('time_of_day'),
        supabase
          .from('motivation_logs')
          .select('*')
          .order('date', { ascending: false })
          .limit(7)
      ]);

      // Handle specific errors for each request
      if (actionsResponse.error) {
        console.error('Error fetching actions:', actionsResponse.error);
        throw new Error(`Failed to fetch actions: ${actionsResponse.error.message}`);
      }

      if (logsResponse.error) {
        console.error('Error fetching logs:', logsResponse.error);
        throw new Error(`Failed to fetch logs: ${logsResponse.error.message}`);
      }

      setActions(actionsResponse.data || []);
      setLogs(logsResponse.data || []);
      setError(null);
      setRetryCount(0); // Reset retry count on successful fetch
    } catch (err) {
      console.error('Error fetching motivation data:', err);
      
      // Implement retry logic for network errors
      if (err instanceof Error && err.message.includes('Failed to fetch') && retryCount < 3) {
        setRetryCount(prev => prev + 1);
        setTimeout(() => {
          fetchData();
        }, Math.pow(2, retryCount) * 1000); // Exponential backoff
        return;
      }

      setError(
        err instanceof Error 
          ? err.message 
          : 'Failed to load data. Please check your internet connection and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse p-4 space-y-4">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-amber-800 bg-amber-100 dark:bg-amber-900/50 dark:text-amber-400 rounded-lg">
        <p className="mb-2">{error}</p>
        {!error.includes('Please sign in') && (
          <button
            onClick={() => {
              setLoading(true);
              setError(null);
              fetchData();
            }}
            className="text-sm font-medium text-amber-800 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-300"
          >
            Try Again
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {logs.length > 0 && <MotivationStats logs={logs} />}
      
      {showForm ? (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium dark:text-white">Add Motivation Action</h3>
            <button
              onClick={() => setShowForm(false)}
              className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
            >
              Cancel
            </button>
          </div>
          <MotivationActionForm
            onComplete={() => {
              setShowForm(false);
              fetchData();
            }}
          />
        </div>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-2 px-4 bg-blue-600 dark:bg-blue-500 text-white rounded-md font-medium hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors"
        >
          Add New Action
        </button>
      )}

      {actions.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium dark:text-white">Daily Actions</h3>
          {actions.map((action) => (
            <div
              key={action.id}
              className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm space-y-3"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium dark:text-white">{action.title}</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {action.timeOfDay} • {action.durationMinutes} minutes
                  </p>
                </div>
              </div>
              
              {action.description && (
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  {action.description}
                </p>
              )}
              
              <div className="text-sm">
                <p className="text-gray-600 dark:text-gray-300">
                  <strong>Why it matters:</strong> {action.importance}
                </p>
                {action.potentialObstacle && (
                  <p className="text-gray-600 dark:text-gray-300 mt-1">
                    <strong>Obstacle:</strong> {action.potentialObstacle}
                    {action.solution && ` → ${action.solution}`}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MotivationTracker;