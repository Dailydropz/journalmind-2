import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import type { MotivationAction } from '../types';

interface MotivationActionFormProps {
  onComplete: () => void;
  initialAction?: MotivationAction;
}

const MotivationActionForm: React.FC<MotivationActionFormProps> = ({
  onComplete,
  initialAction
}) => {
  const [title, setTitle] = useState(initialAction?.title || '');
  const [description, setDescription] = useState(initialAction?.description || '');
  const [timeOfDay, setTimeOfDay] = useState(initialAction?.timeOfDay || '09:00');
  const [durationMinutes, setDurationMinutes] = useState(initialAction?.durationMinutes || 15);
  const [importance, setImportance] = useState(initialAction?.importance || '');
  const [potentialObstacle, setPotentialObstacle] = useState(initialAction?.potentialObstacle || '');
  const [solution, setSolution] = useState(initialAction?.solution || '');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError) throw authError;
      if (!user) throw new Error('Not authenticated');

      const actionData = {
        user_id: user.id,
        title,
        description,
        time_of_day: timeOfDay,
        duration_minutes: durationMinutes,
        importance,
        potential_obstacle: potentialObstacle,
        solution
      };

      if (initialAction) {
        const { error: updateError } = await supabase
          .from('motivation_actions')
          .update(actionData)
          .eq('id', initialAction.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('motivation_actions')
          .insert(actionData);

        if (insertError) throw insertError;
      }

      onComplete();
    } catch (err) {
      console.error('Error saving motivation action:', err);
      setError(err instanceof Error ? err.message : 'Failed to save action');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-4 text-sm text-red-800 bg-red-100 dark:bg-red-900/50 dark:text-red-400 rounded-lg">
          {error}
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Action Title
        </label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Description
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
          rows={2}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Time of Day
          </label>
          <input
            type="time"
            value={timeOfDay}
            onChange={(e) => setTimeOfDay(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Duration (minutes)
          </label>
          <input
            type="number"
            min="1"
            max="15"
            value={durationMinutes}
            onChange={(e) => setDurationMinutes(parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Why This Matters
        </label>
        <textarea
          value={importance}
          onChange={(e) => setImportance(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
          rows={2}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Potential Obstacle
        </label>
        <input
          type="text"
          value={potentialObstacle}
          onChange={(e) => setPotentialObstacle(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Solution to Obstacle
        </label>
        <input
          type="text"
          value={solution}
          onChange={(e) => setSolution(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm dark:bg-gray-700 dark:text-white"
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-2 px-4 bg-blue-600 dark:bg-blue-500 text-white rounded-md font-medium hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors disabled:opacity-50"
      >
        {isSubmitting ? 'Saving...' : initialAction ? 'Update Action' : 'Add Action'}
      </button>
    </form>
  );
};

export default MotivationActionForm;