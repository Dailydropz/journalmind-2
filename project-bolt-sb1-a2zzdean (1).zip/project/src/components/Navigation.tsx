import React from 'react';
import { Home, History, BarChart2, Settings } from 'lucide-react';

interface NavigationProps {
  currentRoute: string;
}

const Navigation: React.FC<NavigationProps> = ({ currentRoute }) => {
  const navigateTo = (path: string) => {
    window.location.hash = path;
  };

  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/history', label: 'History', icon: History },
    { path: '/analytics', label: 'Analytics', icon: BarChart2 },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 pb-safe">
      <div className="max-w-md mx-auto flex justify-around items-center">
        {navItems.map(({ path, label, icon: Icon }) => (
          <button
            key={path}
            onClick={() => navigateTo(path)}
            className={`flex flex-col items-center py-2 px-4 ${
              currentRoute === path 
                ? 'text-blue-600 dark:text-blue-400' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            aria-label={label}
          >
            <Icon size={24} />
            <span className="text-xs mt-1">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}

export default Navigation;