import React from 'react';
import { MotivationLog } from '../types';

interface MotivationStatsProps {
  logs: MotivationLog[];
}

const MotivationStats: React.FC<MotivationStatsProps> = ({ logs }) => {
  const averageMotivation = logs.length > 0
    ? Math.round((logs.reduce((sum, log) => sum + log.motivationRating, 0) / logs.length) * 10) / 10
    : 0;

  const streak = logs.reduce((count, log, index) => {
    if (index === 0) return 1;
    const prevDate = new Date(logs[index - 1].date);
    const currentDate = new Date(log.date);
    const diffDays = Math.floor((prevDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays === 1 ? count + 1 : count;
  }, 0);

  const motivationTrend = logs.length >= 3
    ? logs[0].motivationRating > logs[logs.length - 1].motivationRating
      ? 'increasing'
      : logs[0].motivationRating < logs[logs.length - 1].motivationRating
        ? 'decreasing'
        : 'stable'
    : 'not enough data';

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
      <h3 className="text-lg font-medium dark:text-white mb-4">Motivation Insights</h3>
      
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
            {averageMotivation}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Average Rating
          </div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600 dark:text-green-400">
            {streak}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Day Streak
          </div>
        </div>
        
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
            {logs.length}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Total Logs
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <h4 className="text-sm font-medium dark:text-white">Trend Analysis</h4>
        <div className="flex items-center space-x-2 text-sm">
          <span className="text-gray-600 dark:text-gray-300">
            Your motivation is{' '}
            <span className={`font-medium ${
              motivationTrend === 'increasing'
                ? 'text-green-600 dark:text-green-400'
                : motivationTrend === 'decreasing'
                  ? 'text-red-600 dark:text-red-400'
                  : 'text-blue-600 dark:text-blue-400'
            }`}>
              {motivationTrend}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
};

export default MotivationStats;