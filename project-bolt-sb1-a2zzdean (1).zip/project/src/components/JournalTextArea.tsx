import React, { useState, useEffect } from 'react';
import { JournalPrompt, MoodRating } from '../types';

interface JournalTextAreaProps {
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
  currentMood?: MoodRating | null;
  prompts?: JournalPrompt[];
}

const JournalTextArea: React.FC<JournalTextAreaProps> = ({
  value,
  onChange,
  maxLength = 2000, // Increased for more detailed reflections
  currentMood,
  prompts = [],
}) => {
  const [prompt, setPrompt] = useState<string | null>(null);
  const [showPromptSuggestions, setShowPromptSuggestions] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    if (currentMood && prompts.length > 0 && showPromptSuggestions) {
      const relevantPrompts = prompts.filter(
        (p) => !p.forMood || p.forMood === currentMood
      );
      
      if (relevantPrompts.length > 0) {
        const randomPrompt = relevantPrompts[Math.floor(Math.random() * relevantPrompts.length)];
        setPrompt(randomPrompt.text);
      }
    }
  }, [currentMood, prompts, showPromptSuggestions]);

  const handleUsePrompt = () => {
    if (prompt) {
      onChange(`${prompt}\n\n${value}`.trim());
      setPrompt(null);
      setShowPromptSuggestions(false);
      setIsExpanded(true);
    }
  };

  const handleSkipPrompt = () => {
    setPrompt(null);
    setShowPromptSuggestions(false);
  };

  const charactersLeft = maxLength - value.length;
  const isNearLimit = charactersLeft < maxLength * 0.1;

  const handleFocus = () => {
    setIsExpanded(true);
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <h3 className="text-md font-medium text-gray-700 dark:text-gray-300">
          Personal Reflection
        </h3>
        <span 
          className={`text-xs ${
            isNearLimit 
              ? 'text-red-500 dark:text-red-400' 
              : 'text-gray-500 dark:text-gray-400'
          }`}
        >
          {charactersLeft.toLocaleString()} characters remaining
        </span>
      </div>
      
      {prompt && (
        <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg border border-blue-100 dark:border-blue-800">
          <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
            ✨ Reflection prompt:
          </p>
          <p className="text-md text-gray-800 dark:text-gray-200 italic mb-3">
            "{prompt}"
          </p>
          <div className="flex space-x-3">
            <button 
              onClick={handleUsePrompt}
              className="text-sm px-4 py-2 bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-200 dark:hover:bg-blue-700 transition-colors"
            >
              Use this prompt
            </button>
            <button 
              onClick={handleSkipPrompt}
              className="text-sm px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            >
              Skip
            </button>
          </div>
        </div>
      )}
      
      <div className="relative">
        <textarea
          value={value}
          onChange={(e) => {
            if (e.target.value.length <= maxLength) {
              onChange(e.target.value);
            }
          }}
          onFocus={handleFocus}
          className={`w-full p-4 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none transition-all duration-300 ${
            isExpanded ? 'min-h-[300px]' : 'min-h-[200px]'
          }`}
          placeholder="How are you feeling today? Take a moment to reflect on your thoughts, experiences, and emotions..."
        />
        
        {value.length === 0 && !isExpanded && (
          <div className="absolute top-16 left-4 right-4 text-sm text-gray-500 dark:text-gray-400 pointer-events-none">
            <p className="mb-3 font-medium">✍️ Writing suggestions:</p>
            <ul className="space-y-2">
              <li>• What emotions are you experiencing right now?</li>
              <li>• Describe a meaningful moment from today</li>
              <li>• What are you looking forward to?</li>
              <li>• What's something you're grateful for?</li>
              <li>• How did you practice self-care today?</li>
            </ul>
          </div>
        )}
      </div>
      
      {value.length > 0 && (
        <div className="flex justify-end">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {value.split(/\s+/).length} words
          </p>
        </div>
      )}
    </div>
  );
};

export default JournalTextArea;